#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cogctl.py
---------

CLI mínima para orquestar los distintos módulos de la suite cognitiva.
Implementa subcomandos mediante el módulo estándar ``argparse`` para
eliminar dependencias externas como ``typer``. Los comandos disponibles
son:

- ``init``    → Crear la estructura básica de carpetas.
- ``ingest``  → Ingerir un archivo específico mediante el módulo de ingesta.
- ``analyze`` → Ejecutar el pipeline de análisis sobre los textos ingeridos.
- ``deploy``  → Levantar los servicios definidos en ``docker-compose.yml``.
- ``status``  → Mostrar el estado de los contenedores Docker.

Uso:

```
python cogctl.py init
python cogctl.py ingest nombre_archivo.ext
python cogctl.py analyze
python cogctl.py deploy
python cogctl.py status
```
"""

import argparse
import os
import subprocess
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
INPUT_DIR = BASE_DIR / 'data' / 'input'
RAW_DIR = BASE_DIR / 'outputs' / 'raw'
INSIGHTS_DIR = BASE_DIR / 'outputs' / 'insights'


def cmd_init(args: argparse.Namespace) -> None:
    """Inicializa la estructura de carpetas requerida."""
    for p in [INPUT_DIR, RAW_DIR, INSIGHTS_DIR]:
        p.mkdir(parents=True, exist_ok=True)
    print('📁 Estructura creada: data/input, outputs/raw, outputs/insights')


def cmd_ingest(args: argparse.Namespace) -> None:
    """Ingesta un archivo individual mediante el módulo ``ingestor``."""
    target = INPUT_DIR / args.file
    if not target.exists():
        print(f'❌ Archivo no encontrado en data/input: {args.file}')
        raise SystemExit(1)
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    print(f'📥 Ingestando {args.file}...')
    subprocess.run([
        'python',
        str(BASE_DIR / 'ingestor' / 'ingest.py'),
        str(target),
        '--output',
        str(RAW_DIR)
    ], check=True)


def cmd_analyze(args: argparse.Namespace) -> None:
    """Ejecuta el análisis cognitivo sobre los textos ingeridos."""
    INSIGHTS_DIR.mkdir(parents=True, exist_ok=True)
    print('🧠 Ejecutando análisis cognitivo...')
    subprocess.run([
        'python',
        str(BASE_DIR / 'pipeline' / 'analyze.py'),
        '--input', str(RAW_DIR),
        '--output', str(INSIGHTS_DIR / 'analysis.json'),
        '--schema', str(BASE_DIR / 'schemas' / 'cognitive-schema.yaml')
    ], check=True)
    print('✅ Análisis completado. Resultados en outputs/insights/analysis.json')


def cmd_deploy(args: argparse.Namespace) -> None:
    """Despliega los servicios definidos en docker-compose."""
    print('🚀 Desplegando servicios...')
    subprocess.run(['docker-compose', 'up', '-d'], check=True)


def cmd_status(args: argparse.Namespace) -> None:
    """Muestra el estado actual de los contenedores Docker."""
    subprocess.run(['docker', 'ps'], check=True)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description='Cognitive GitOps Suite CLI')
    subparsers = parser.add_subparsers(title='comandos', dest='command')

    # init
    parser_init = subparsers.add_parser('init', help='Inicializa la estructura de carpetas')
    parser_init.set_defaults(func=cmd_init)

    # ingest
    parser_ingest = subparsers.add_parser('ingest', help='Ingesta un archivo desde data/input')
    parser_ingest.add_argument('file', help='Nombre del archivo en data/input a ingerir')
    parser_ingest.set_defaults(func=cmd_ingest)

    # analyze
    parser_analyze = subparsers.add_parser('analyze', help='Ejecuta el análisis cognitivo')
    parser_analyze.set_defaults(func=cmd_analyze)

    # deploy
    parser_deploy = subparsers.add_parser('deploy', help='Despliega servicios con docker-compose')
    parser_deploy.set_defaults(func=cmd_deploy)

    # status
    parser_status = subparsers.add_parser('status', help='Muestra el estado de los contenedores')
    parser_status.set_defaults(func=cmd_status)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if not hasattr(args, 'func'):
        parser.print_help()
        return
    args.func(args)


if __name__ == '__main__':
    main()