# 🧠 Estrategia de Cómputo: Local vs GitHub Actions

Este documento define qué tareas ejecutar localmente y cuáles aprovechar desde runners públicos o contenedores GPU en GitHub Actions.

---

## ⚖️ Matriz de decisión

| Tarea | Recursos | Riesgo | ⚙️ Local | ☁️ GitHub Actions |
|-------|----------|--------|----------|------------------|
| 🧪 Pruebas YAML/Python | Bajo (CPU) | Bajo | ✅ | ✅ |
| 🧠 Análisis SpaCy | Medio (RAM) | Medio | ✅ | ✅ |
| 🧬 Entrenamiento ML | Alto (GPU) | Alto | ⚠️ Limitado | ✅ (Docker GPU) |
| 🎯 Análisis batch | Alto (CPU Hilos) | Medio | ⚠️ | ✅ |
| 📦 Build Docker | Medio | Bajo | ✅ | ✅ |
| 📤 GitOps auto-push | Bajo | Alto | ✅ | 🚫 |
| 🔍 Scan CodeQL/Rego | Medio | Alto | ✅ | ✅ |

---

## 🧭 Reglas generales

- **Local**: Pruebas iterativas rápidas, control de credenciales, GitOps controlado
- **GitHub Actions**: Validación pública, entrenamiento pesado, testing GPU

---

## 🔐 Seguridad
- Nunca subir `.env` o claves locales
- El push GitOps requiere validación manual o GPG firmado desde dev
- Recomendado usar Secrets de GitHub para acceso API/cloud

## 🚀 Tareas pesadas en GitHub Actions

Aunque muchas de las operaciones de la suite se pueden ejecutar en un portátil o
servidor local, existen procesos que consumen gran cantidad de CPU o GPU
(por ejemplo, análisis con modelos de lenguaje de gran tamaño, indexación de
millones de embeddings o entrenamiento de modelos personalizados). Para
estas situaciones se recomienda delegar el trabajo a los runners públicos de
GitHub Actions.

Se ha incluido un workflow dedicado en `.github/workflows/heavy-tasks.yml` que
permite lanzar análisis intensivos en GitHub. Este flujo de trabajo:

- Instala las dependencias del sistema (FFmpeg, librerías de renderizado),
- Configura Python 3.10 y todas las dependencias de la suite,
- Descarga el modelo de spaCy en español,
- Inicializa la estructura de carpetas, ingiere los archivos de entrada y
  ejecuta el análisis completo, y
- Publica los resultados (`outputs/insights/analysis.json`) como artefacto
  de GitHub para su posterior descarga.

Puedes ejecutarlo manualmente desde la pestaña **Actions** de GitHub o
programarlo mediante un evento `workflow_dispatch` o un cron. Si cuentas
con runners autoservicio con GPU, ajusta el atributo `runs-on` para
aprovecharlos.
